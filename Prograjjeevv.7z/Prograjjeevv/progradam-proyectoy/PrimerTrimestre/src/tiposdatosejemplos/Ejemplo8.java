package tiposdatosejemplos;

import java.io.*;

public class Ejemplo8
{
		
	public static void main(String args[])
	{
		//float f=123.45;
		double d=234.56e+34;
				
		//System.out.println("El valor de f es "+f);
		System.out.println("El valor de d es "+d);
		

		
	}
}