package tiposdatosejemplos;

import java.io.*;

public class Ejemplo5
{
		
	public static void main(String args[])
	{
		/*byte b=-129;
		short s=32768;
		int i=-2147483649;
		long l=9223372036854775808L;
		
		System.out.println("El valor de b es "+b);
		System.out.println("El valor de s es "+s);
		System.out.println("El valor de i es "+i);
		System.out.println("El valor de l es "+l);
*/
		
	}
}