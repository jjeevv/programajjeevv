import java.io.*;

public class Ejemplo9
{
		
	public static void main(String args[])
	{
		float f=123.45F;
		double d=234.56e+34;
				
		System.out.println("El valor de f es "+f);
		System.out.println("El valor de d es "+d);
		

		
	}
}