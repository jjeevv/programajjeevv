package tiposdatosejemplos;

import java.io.*;

public class Ejemplo11
{
		
	public static void main(String args[])
	{
	
		//char c="p";
		
		//System.out.println("El valor de c es: "+c);
		
	}
}