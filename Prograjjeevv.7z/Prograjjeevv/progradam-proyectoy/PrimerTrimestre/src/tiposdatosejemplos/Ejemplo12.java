import java.io.*;

public class Ejemplo12
{
		
	public static void main(String args[])
	{
	
		boolean b1=true;
		boolean b2=false;
		
		if(b1){
		
		System.out.println("b1 es "+b1);
		
		}
		
		if(!b2){
		
		System.out.println("b2 es "+b2);
		
		} 
		
		
		}
}