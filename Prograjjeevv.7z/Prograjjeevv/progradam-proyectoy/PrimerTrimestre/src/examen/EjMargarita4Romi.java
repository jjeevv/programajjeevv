package examen;

/**
 *
 * @author Julian
 */
public class EjMargarita4Romi {
        public static void main(String args[]){
        int petalosMargaritas = 10;
        int totalAlumnos = 6;
        int numeroAlumno [] = new int [totalAlumnos];
        int sumador = 0;
        
        //LLenar lista de unos
        for (int i = 0; i < numeroAlumno.length; i++) {
                numeroAlumno[i]=1;
        }//fin del for
        
        //Hace esto por cada alumno, para sacar uno
        for (int i = 0; i < totalAlumnos; i++) {
            while (sumador < petalosMargaritas){
                
            }
        }
        
        
        }//fin main
}
