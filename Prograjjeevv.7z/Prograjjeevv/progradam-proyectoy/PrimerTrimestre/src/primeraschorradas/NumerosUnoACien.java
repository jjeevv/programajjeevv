/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeraschorradas;

/**
 *
 * @author Julian Gawron
 */
public class NumerosUnoACien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Desde i<-1 hasta 100 incremento 
        // escribir el valor
        
        for (int i = 1; i <= 100; i++) {
            System.out.println("El valor de i es:"+ i);
        }
    }
    
}
