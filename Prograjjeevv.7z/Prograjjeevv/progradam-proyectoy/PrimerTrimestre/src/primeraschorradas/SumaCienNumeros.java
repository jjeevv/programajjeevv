/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package primeraschorradas;

/**
 *
 * @author DAM1
 */
public class SumaCienNumeros {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*
        Var 
        Entero: i, acumulador
        Inicio 
            i<- 0
            acumulador <- 0
        
        desde i = 0 hasta 100 incremento 1
            acumulador <- acumulador + i
        fin_desde
        
        escribir("La suma es:" + i)
        */
        /*
        int acumulador = 0;
        int i = 0;
        do {
        acumulador = acumulador + i;    
        i++;
        } while (i <= 100);
        System.out.printf(" El resultado es: %d ", acumulador);
        */
        
        
                
    }
    
}
