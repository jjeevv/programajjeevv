/*
BOLETÍN 1: EJERCICIOS INICIALES JAVA
1.	Leer un número y mostrar su cuadrado, 
        repetir el proceso hasta que se introduzca un número negativo.
2.	Leer un número e indicar si es positivo o negativo. El proceso se 
        repetirá hasta que se introduzca un 0.
3.	Leer números hasta que se introduzca un 0. Para cada uno indicar si es 
        par o impar.
4.	Pedir números hasta que se teclee uno negativo, y mostrar cuántos 
        números se han introducido.
5.	Realizar un juego para adivinar un número. Para ello pedir un número N, 
        y luego ir pidiendo números indicando “mayor” o “menor” según sea mayor 
        o menor con respecto a N. El proceso termina cuando el usuario acierta.
6.	Realizar un programa en JAVA que pida dos números, los ordene de menor 
        a mayor y cuente cuántos pares e impares hay entre ellos.

 */
package Boletin1;

/**
 *
 * @author DAM1
 */
public class BoletinJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
