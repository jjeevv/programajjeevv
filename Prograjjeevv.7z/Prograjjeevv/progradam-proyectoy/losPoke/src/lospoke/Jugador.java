package lospoke;

import java.util.ArrayList;

/**
 *
 * @author Julian
 */
public class Jugador {
    ArrayList<Pokemon> MisPokes = new ArrayList();
}
