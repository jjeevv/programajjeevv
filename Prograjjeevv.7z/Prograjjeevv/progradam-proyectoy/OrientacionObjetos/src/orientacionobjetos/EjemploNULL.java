package orientacionobjetos;

/**
 *
 * @author DAM1
 */
public class EjemploNULL {
    public static void main(String[] args){
        double[] valorDoble;
        char[] charlos;
        int[] miNum;
        int[] arrayNum; //arrayNum es una variable capaz de apuntar a un array 
        String[] cadena = new String[2];
        // cadena = new String("Hola esto es todo");
        cadena[0].charAt(0); // peta por pedir un metodo a un obj null.
       
    }
}
